import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{    
    int mSpeed;
    
    // Konstruktor.
    public Bullet(int pRotation, int pSpeed)
    {
        setRotation(pRotation);
        mSpeed = pSpeed;
    }
        
    // Wird zyklisch aufgerufen.
    public void act() 
    {
        move(mSpeed);
        if(isAtEdge())
        {
            getWorld().removeObject(this);
        }
        
        else if(this.canSee(Enemy.class))
        {
            eat(Enemy.class);
            getWorld().removeObject(this);
        }
    }    
    
    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }
    
    public void eat(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        if(actor != null) {
            getWorld().removeObject(actor);
        }
    }
}
