import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{    
    private int mCounter = 0;
    private boolean mHasShot = false;
    private int mDelay;
    private int mWeapon = 1;
    private boolean mFalls = false;
    
    // Konstruktor.
    public Player()
    {
        Fall();
    }
    
    // Wird zyklisch aufgerufen.
    public void act()
    {
        // TEMP
        if(Greenfoot.isKeyDown("1"))
        {
            changeWeapon(0);
        }
        else if(Greenfoot.isKeyDown("2"))
        {
            changeWeapon(1);
        }
        // TEMP ENDE
        
        // Abfragen für Aktionen.
        if(Greenfoot.isKeyDown("space"))
        {
            Shoot();
        }
        else if(Greenfoot.isKeyDown("A"))
        {
            move(-3);
            if(!hitsGround())
            {
                Fall();
            }
        }
        else if(Greenfoot.isKeyDown("D"))
        {
            move(3);
            if(!hitsGround())
            {
                Fall();
            }
        }        
        // Delay für die Waffe.
        if(mHasShot)
        {
            if(mCounter < mDelay)
            {
                mCounter ++;
            }
            else
            {
                mHasShot = false;
            }
        }
        // Fall-Variable.
        if(mFalls)
        {
            setLocation(getX(), getY() + 5);
            if(hitsGround())
            {
                mFalls = false;
                setLocation(getX(), getY() - 1);
            }
        }
    }
    
    // Lässt den Charakter schießen.
    private void Shoot()
    {
        if(!mHasShot)
        {
            mCounter = 0;
            mHasShot = true;
            World lWorld = getWorld();
            switch (mWeapon)
            {
                case 0:
                    lWorld.addObject(new Bullet(getRotation(), 50), getX(), getY());
                    //TODO: Greenfoot.playSound(" ? ");
                    mDelay = 20;
                break;
                case 1:
                    lWorld.addObject(new Bullet(getRotation(), 80), getX(), getY() - 10);
                    Greenfoot.playSound("AWPkurz.wav");
                    mDelay = 50;
                break;
            }
        }
    }
    
    // Prüft, ob der Charakter den Boden trifft.
    private boolean hitsGround()
    {
        return (getOneIntersectingObject(Ground.class) != null);
    }
    
    // Lässt den Charakter fallen.
    private void Fall()
    {
        mFalls = true;
    }
    
    // Wechselt den Waffentyp sowie das Anzeigebild.
    private void changeWeapon(int pWeapon)
    {
        mWeapon = pWeapon;
        switch(mWeapon)
        {
            case 0:
             //TODO:  setImage("Player01.png");
                break;
            case 1:
             //TODO:   setImage("Player02.png");
                break;
        }
    }
}
